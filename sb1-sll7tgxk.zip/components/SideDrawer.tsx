import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  ScrollView,
  Image,
  Platform,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { X, User, Settings, Bell, CircleHelp as HelpCircle, Shield, Heart, Star, MapPin, Calendar, Users, MessageCircle, Bookmark, CreditCard, Gift, Share2, LogOut, ChevronRight } from 'lucide-react-native';

interface SideDrawerProps {
  visible: boolean;
  onClose: () => void;
}

interface MenuItem {
  id: string;
  title: string;
  icon: React.ReactNode;
  route?: string;
  action?: () => void;
  badge?: string;
  divider?: boolean;
}

export default function SideDrawer({ visible, onClose }: SideDrawerProps) {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const handleNavigation = (route: string) => {
    onClose();
    router.push(route);
  };

  const handleAction = (action: () => void) => {
    onClose();
    action();
  };

  const menuItems: MenuItem[] = [
    {
      id: 'profile',
      title: 'My Profile',
      icon: <User size={22} color="#666" />,
      route: '/me',
    },
    {
      id: 'bookings',
      title: 'My Bookings',
      icon: <Calendar size={22} color="#666" />,
      route: '/bookings',
      badge: '3',
    },
    {
      id: 'favorites',
      title: 'Saved Events',
      icon: <Bookmark size={22} color="#666" />,
      route: '/favorites',
    },
    {
      id: 'friends',
      title: 'Friends',
      icon: <Users size={22} color="#666" />,
      route: '/friends',
    },
    {
      id: 'messages',
      title: 'Messages',
      icon: <MessageCircle size={22} color="#666" />,
      route: '/messages',
      badge: '2',
    },
    {
      id: 'divider1',
      title: '',
      icon: null,
      divider: true,
    },
    {
      id: 'nearby',
      title: 'Nearby Events',
      icon: <MapPin size={22} color="#666" />,
      action: () => console.log('Show nearby events'),
    },
    {
      id: 'recommendations',
      title: 'Recommendations',
      icon: <Star size={22} color="#666" />,
      route: '/recommendations',
    },
    {
      id: 'invite',
      title: 'Invite Friends',
      icon: <Gift size={22} color="#666" />,
      action: () => console.log('Invite friends'),
    },
    {
      id: 'share',
      title: 'Share App',
      icon: <Share2 size={22} color="#666" />,
      action: () => console.log('Share app'),
    },
    {
      id: 'divider2',
      title: '',
      icon: null,
      divider: true,
    },
    {
      id: 'notifications',
      title: 'Notifications',
      icon: <Bell size={22} color="#666" />,
      route: '/notifications',
    },
    {
      id: 'settings',
      title: 'Settings',
      icon: <Settings size={22} color="#666" />,
      route: '/settings',
    },
    {
      id: 'privacy',
      title: 'Privacy & Safety',
      icon: <Shield size={22} color="#666" />,
      route: '/privacy',
    },
    {
      id: 'help',
      title: 'Help & Support',
      icon: <HelpCircle size={22} color="#666" />,
      route: '/help',
    },
    {
      id: 'divider3',
      title: '',
      icon: null,
      divider: true,
    },
    {
      id: 'logout',
      title: 'Sign Out',
      icon: <LogOut size={22} color="#E74C3C" />,
      action: () => console.log('Sign out'),
    },
  ];

  const renderMenuItem = (item: MenuItem) => {
    if (item.divider) {
      return <View key={item.id} style={styles.divider} />;
    }

    const handlePress = () => {
      if (item.route) {
        handleNavigation(item.route);
      } else if (item.action) {
        handleAction(item.action);
      }
    };

    return (
      <TouchableOpacity
        key={item.id}
        style={[
          styles.menuItem,
          item.id === 'logout' && styles.logoutItem,
        ]}
        onPress={handlePress}
      >
        <View style={styles.menuItemLeft}>
          {item.icon}
          <Text
            style={[
              styles.menuItemText,
              item.id === 'logout' && styles.logoutText,
            ]}
          >
            {item.title}
          </Text>
        </View>
        
        <View style={styles.menuItemRight}>
          {item.badge && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{item.badge}</Text>
            </View>
          )}
          <ChevronRight size={18} color="#999" />
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      transparent={true}
      onRequestClose={onClose}
    >
      <View style={styles.overlay}>
        <TouchableOpacity
          style={styles.overlayTouchable}
          activeOpacity={1}
          onPress={onClose}
        />
        
        <View style={[styles.drawer, { paddingTop: insets.top }]}>
          {/* Header */}
          <View style={styles.header}>
            <View style={styles.profileSection}>
              <Image
                source={{
                  uri: 'https://images.pexels.com/photos/1821095/pexels-photo-1821095.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
                }}
                style={styles.profileImage}
              />
              <View style={styles.profileInfo}>
                <Text style={styles.profileName}>Jessica Williams</Text>
                <Text style={styles.profileLocation}>Newton, Singapore</Text>
                <View style={styles.profileStats}>
                  <View style={styles.statItem}>
                    <Heart size={14} color="#E74C3C" fill="#E74C3C" />
                    <Text style={styles.statText}>128 events</Text>
                  </View>
                  <View style={styles.statItem}>
                    <Star size={14} color="#FFD700" fill="#FFD700" />
                    <Text style={styles.statText}>Social Butterfly</Text>
                  </View>
                </View>
              </View>
            </View>
            
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <X size={24} color="#666" />
            </TouchableOpacity>
          </View>

          {/* Menu Items */}
          <ScrollView
            style={styles.menuContainer}
            contentContainerStyle={[
              styles.menuContent,
              { paddingBottom: insets.bottom + 20 }
            ]}
            showsVerticalScrollIndicator={false}
          >
            {menuItems.map(renderMenuItem)}
            
            {/* App Version */}
            <View style={styles.versionContainer}>
              <Text style={styles.versionText}>Let's Hang! v1.0.0</Text>
              <Text style={styles.versionSubtext}>Made with ❤️ in Singapore</Text>
            </View>
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    flexDirection: 'row',
  },
  overlayTouchable: {
    flex: 1,
  },
  drawer: {
    width: '85%',
    maxWidth: 320,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 2, height: 0 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
    elevation: 10,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    padding: 20,
    paddingTop: 30,
    backgroundColor: '#F5F8FF',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  profileSection: {
    flexDirection: 'row',
    flex: 1,
  },
  profileImage: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: '#A8C2EE',
  },
  profileInfo: {
    marginLeft: 12,
    flex: 1,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '700',
    color: '#333',
  },
  profileLocation: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  profileStats: {
    flexDirection: 'row',
    marginTop: 8,
    gap: 12,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    fontSize: 12,
    color: '#666',
    fontWeight: '500',
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  menuContainer: {
    flex: 1,
  },
  menuContent: {
    paddingVertical: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 0.5,
    borderBottomColor: '#F0F0F0',
  },
  menuItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  menuItemText: {
    fontSize: 16,
    color: '#333',
    marginLeft: 16,
    fontWeight: '500',
  },
  menuItemRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  badge: {
    backgroundColor: '#E74C3C',
    borderRadius: 10,
    minWidth: 20,
    height: 20,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 6,
  },
  badgeText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  divider: {
    height: 1,
    backgroundColor: '#E0E0E0',
    marginVertical: 8,
    marginHorizontal: 20,
  },
  logoutItem: {
    borderBottomWidth: 0,
  },
  logoutText: {
    color: '#E74C3C',
    fontWeight: '600',
  },
  versionContainer: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  versionText: {
    fontSize: 14,
    color: '#999',
    fontWeight: '500',
  },
  versionSubtext: {
    fontSize: 12,
    color: '#BBB',
    marginTop: 4,
  },
});