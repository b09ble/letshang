import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Flower, Star, MapPin, Apple } from 'lucide-react-native';

interface CategoryProps {
  icon: React.ReactNode;
  label: string;
  onPress: () => void;
}

const CategoryButton: React.FC<CategoryProps> = ({ icon, label, onPress }) => (
  <TouchableOpacity style={styles.categoryButton} onPress={onPress}>
    <View style={styles.iconContainer}>
      {icon}
    </View>
    <Text style={styles.categoryText}>{label}</Text>
  </TouchableOpacity>
);

export default function Categories() {
  const handleCategoryPress = (category: string) => {
    // Handle category selection
    console.log(`Selected category: ${category}`);
  };

  return (
    <View style={styles.container}>
      <View style={styles.categoriesRow}>
        <CategoryButton 
          icon={<Flower size={28} color="#4CAF50" />} 
          label="Explore" 
          onPress={() => handleCategoryPress('Explore')} 
        />
        <CategoryButton 
          icon={<Star size={28} color="#FFC107" />} 
          label="Popular" 
          onPress={() => handleCategoryPress('Popular')} 
        />
        <CategoryButton 
          icon={<MapPin size={28} color="#E91E63" />} 
          label="Near Me" 
          onPress={() => handleCategoryPress('Location')} 
        />
        <CategoryButton 
          icon={<Apple size={28} color="#F44336" />} 
          label="Food" 
          onPress={() => handleCategoryPress('Food')} 
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#F5F8FF',
    padding: 12,
    borderRadius: 16,
    marginHorizontal: 16,
    marginVertical: 12,
    borderWidth: 1,
    borderColor: '#D1DFFA',
    borderStyle: 'dashed',
  },
  categoriesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  categoryButton: {
    alignItems: 'center',
    width: '23%',
  },
  iconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'white',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  categoryText: {
    fontSize: 12,
    color: '#666',
    textAlign: 'center',
  },
});