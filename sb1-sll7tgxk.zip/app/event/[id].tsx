import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
  Platform,
  Linking,
  Share,
  Dimensions,
} from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  Bookmark,
  Share2,
  MessageCircle,
  MapPin,
  Clock,
  Users,
  Phone,
  Globe,
  Mail,
  Star,
  Calendar,
  DollarSign,
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

// Mock event data - in a real app, this would come from an API
const EVENT_DATA = {
  '1': {
    id: '1',
    title: 'Rooftop Party',
    location: 'Chinatown Heritage Centre, 48 Pagoda Street',
    time: 'Sat, Jun 21 • 7:00 PM - 12:00 AM',
    attendees: 85,
    price: '$35',
    imageUrl: 'https://images.pexels.com/photos/2788488/pexels-photo-2788488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Join us for an unforgettable rooftop party in the heart of Chinatown! Experience stunning city views, amazing music, and great vibes under the stars.',
    fullDescription: 'Get ready for the ultimate rooftop experience in Singapore\'s historic Chinatown district! Our rooftop party offers breathtaking 360-degree views of the city skyline, featuring both modern skyscrapers and traditional shophouses.\n\nThe evening kicks off at 7 PM with welcome cocktails and light bites, followed by live DJ sets from some of Singapore\'s hottest talents. Dance the night away under the open sky while enjoying premium drinks from our rooftop bar.\n\nHighlights include:\n• Panoramic city views\n• Live DJ performances\n• Premium cocktail bar\n• Gourmet canapés and finger foods\n• Photo opportunities with stunning backdrops\n• Networking with like-minded party-goers\n\nDress code: Smart casual to cocktail attire. Weather contingency plans in place.',
    contact: {
      phone: '+65 6789 1234',
      email: 'events@rooftopchinatown.sg',
      website: 'https://rooftopchinatown.sg',
    },
    organizer: 'Skyline Events Singapore',
    category: 'Nightlife & Entertainment',
    rating: 4.7,
    reviewCount: 156,
  },
  '2': {
    id: '2',
    title: 'Beach Volleyball',
    location: 'Sentosa Beach',
    time: 'Sun, Jun 22 • 10:00 AM - 2:00 PM',
    attendees: 24,
    price: '$15',
    imageUrl: 'https://images.pexels.com/photos/1263426/pexels-photo-1263426.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Fun beach volleyball tournament at Sentosa Beach. All skill levels welcome!',
    fullDescription: 'Join us for a fun-filled beach volleyball tournament at the beautiful Sentosa Beach. Whether you\'re a seasoned player or just starting out, this event welcomes all skill levels.\n\nWe\'ll provide all equipment including volleyballs, nets, and refreshments. Come ready to play, make new friends, and enjoy the sun and sand!\n\nWhat\'s included:\n• Professional volleyball equipment\n• Refreshments and snacks\n• Tournament prizes\n• Beach games and activities\n• Group photos\n\nBring sunscreen, water, and your competitive spirit!',
    contact: {
      phone: '+65 6234 5678',
      email: 'play@sentosavolleyball.sg',
      website: 'https://sentosavolleyball.sg',
    },
    organizer: 'Sentosa Sports Club',
    category: 'Sports & Recreation',
    rating: 4.5,
    reviewCount: 89,
  },
  '3': {
    id: '3',
    title: 'Dinner Social',
    location: 'Orchard',
    time: 'Fri, Jun 20 • 6:30 PM - 9:30 PM',
    attendees: 32,
    price: '$45',
    imageUrl: 'https://images.pexels.com/photos/696218/pexels-photo-696218.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    description: 'Elegant dinner social at a premium restaurant in Orchard Road.',
    fullDescription: 'Join us for an elegant dinner social at one of Orchard Road\'s most prestigious restaurants. This is the perfect opportunity to meet new people while enjoying exquisite cuisine in a sophisticated setting.\n\nThe evening features a carefully curated 3-course menu showcasing modern Asian fusion cuisine, paired with premium wines and cocktails. Our intimate setting encourages meaningful conversations and lasting connections.\n\nEvening highlights:\n• 3-course gourmet dinner\n• Wine and cocktail pairings\n• Networking opportunities\n• Live acoustic music\n• Professional photography\n• Welcome reception with canapés\n\nSmart casual to formal attire recommended.',
    contact: {
      phone: '+65 6345 6789',
      email: 'reservations@orchardfinedining.sg',
      website: 'https://orchardfinedining.sg',
    },
    organizer: 'Orchard Fine Dining Society',
    category: 'Food & Dining',
    rating: 4.8,
    reviewCount: 203,
  },
};

const REVIEWS = [
  {
    id: '1',
    name: 'Alex Chen',
    rating: 5,
    comment: 'Amazing rooftop party! The views were incredible and the music was perfect. Great crowd and fantastic atmosphere. Will definitely attend again!',
    date: '3 days ago',
  },
  {
    id: '2',
    name: 'Sarah Lim',
    rating: 4,
    comment: 'Really enjoyed the party! Great location and well-organized event. The cocktails were a bit pricey but the overall experience was worth it.',
    date: '1 week ago',
  },
  {
    id: '3',
    name: 'Marcus Wong',
    rating: 5,
    comment: 'Best rooftop party in Singapore! The organizers did an excellent job with the setup and entertainment. Perfect for meeting new people.',
    date: '2 weeks ago',
  },
  {
    id: '4',
    name: 'Emily Tan',
    rating: 4,
    comment: 'Great vibes and stunning city views. The DJ was fantastic and kept everyone dancing all night. Highly recommend for a fun night out!',
    date: '3 weeks ago',
  },
];

export default function EventDetail() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [showFullDescription, setShowFullDescription] = useState(false);

  const event = EVENT_DATA[id as string];

  if (!event) {
    return (
      <View style={styles.errorContainer}>
        <Text style={styles.errorText}>Event not found</Text>
        <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
          <Text style={styles.backButtonText}>Go Back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const handleBookmark = () => {
    setIsBookmarked(!isBookmarked);
  };

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Check out this event: ${event.title} at ${event.location}`,
        url: `https://letshang.app/event/${event.id}`,
      });
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const handleContact = (type: 'phone' | 'email' | 'website') => {
    switch (type) {
      case 'phone':
        Linking.openURL(`tel:${event.contact.phone}`);
        break;
      case 'email':
        Linking.openURL(`mailto:${event.contact.email}`);
        break;
      case 'website':
        Linking.openURL(event.contact.website);
        break;
    }
  };

  const handleChat = () => {
    // In a real app, this would open a chat interface
    console.log('Opening chat with business...');
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} size={16} color="#FFD700" fill="#FFD700" />);
    }

    if (hasHalfStar) {
      stars.push(<Star key="half" size={16} color="#FFD700" fill="#FFD700" style={{ opacity: 0.5 }} />);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} size={16} color="#DDD" />);
    }

    return stars;
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
          <ArrowLeft size={24} color="#333" />
        </TouchableOpacity>
        <View style={styles.headerActions}>
          <TouchableOpacity onPress={handleBookmark} style={styles.headerButton}>
            <Bookmark
              size={24}
              color={isBookmarked ? "#A8C2EE" : "#333"}
              fill={isBookmarked ? "#A8C2EE" : "transparent"}
            />
          </TouchableOpacity>
          <TouchableOpacity onPress={handleShare} style={styles.headerButton}>
            <Share2 size={24} color="#333" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Event Image */}
        <Image source={{ uri: event.imageUrl }} style={styles.eventImage} />

        {/* Event Info */}
        <View style={styles.eventInfo}>
          <Text style={styles.eventTitle}>{event.title}</Text>
          
          <View style={styles.ratingContainer}>
            <View style={styles.starsContainer}>
              {renderStars(event.rating)}
            </View>
            <Text style={styles.ratingText}>
              {event.rating} ({event.reviewCount} reviews)
            </Text>
          </View>

          <View style={styles.detailsContainer}>
            <View style={styles.detailRow}>
              <MapPin size={18} color="#666" />
              <Text style={styles.detailText}>{event.location}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Clock size={18} color="#666" />
              <Text style={styles.detailText}>{event.time}</Text>
            </View>
            
            <View style={styles.detailRow}>
              <Users size={18} color="#666" />
              <Text style={styles.detailText}>{event.attendees} attending</Text>
            </View>
            
            <View style={styles.detailRow}>
              <DollarSign size={18} color="#666" />
              <Text style={styles.detailText}>{event.price}</Text>
            </View>
          </View>

          {/* Description */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>About This Event</Text>
            <Text style={styles.description}>
              {showFullDescription ? event.fullDescription : event.description}
            </Text>
            <TouchableOpacity onPress={() => setShowFullDescription(!showFullDescription)}>
              <Text style={styles.readMoreText}>
                {showFullDescription ? 'Read Less' : 'Read More'}
              </Text>
            </TouchableOpacity>
          </View>

          {/* Organizer Info */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Organizer</Text>
            <View style={styles.organizerContainer}>
              <Text style={styles.organizerName}>{event.organizer}</Text>
              <Text style={styles.organizerCategory}>{event.category}</Text>
            </View>
          </View>

          {/* Contact Information */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Contact Information</Text>
            <View style={styles.contactContainer}>
              <TouchableOpacity
                style={styles.contactButton}
                onPress={() => handleContact('phone')}
              >
                <Phone size={20} color="#A8C2EE" />
                <Text style={styles.contactText}>{event.contact.phone}</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.contactButton}
                onPress={() => handleContact('email')}
              >
                <Mail size={20} color="#A8C2EE" />
                <Text style={styles.contactText}>{event.contact.email}</Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={styles.contactButton}
                onPress={() => handleContact('website')}
              >
                <Globe size={20} color="#A8C2EE" />
                <Text style={styles.contactText}>Visit Website</Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Reviews */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Reviews ({event.reviewCount})</Text>
            {REVIEWS.map((review) => (
              <View key={review.id} style={styles.reviewCard}>
                <View style={styles.reviewHeader}>
                  <Text style={styles.reviewName}>{review.name}</Text>
                  <View style={styles.reviewRating}>
                    {renderStars(review.rating)}
                  </View>
                </View>
                <Text style={styles.reviewComment}>{review.comment}</Text>
                <Text style={styles.reviewDate}>{review.date}</Text>
              </View>
            ))}
            
            <TouchableOpacity style={styles.viewAllReviewsButton}>
              <Text style={styles.viewAllReviewsText}>View All Reviews</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>

      {/* Bottom Actions */}
      <View style={[styles.bottomActions, { paddingBottom: insets.bottom + 20 }]}>
        <TouchableOpacity style={styles.chatButton} onPress={handleChat}>
          <MessageCircle size={20} color="#A8C2EE" />
          <Text style={styles.chatButtonText}>Chat with Business</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.bookButton}>
          <Calendar size={20} color="white" />
          <Text style={styles.bookButtonText}>Book Now</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  errorText: {
    fontSize: 18,
    color: '#666',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: '#A8C2EE',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  backButtonText: {
    color: 'white',
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    backgroundColor: 'rgba(245, 248, 255, 0.95)',
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 12,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: Platform.OS === 'ios' ? 100 : 80,
  },
  eventImage: {
    width: '100%',
    height: 300,
    resizeMode: 'cover',
  },
  eventInfo: {
    padding: 20,
  },
  eventTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 12,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  starsContainer: {
    flexDirection: 'row',
    marginRight: 8,
  },
  ratingText: {
    fontSize: 14,
    color: '#666',
  },
  detailsContainer: {
    marginBottom: 24,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  detailText: {
    fontSize: 16,
    color: '#666',
    marginLeft: 12,
    flex: 1,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  description: {
    fontSize: 16,
    color: '#666',
    lineHeight: 24,
    marginBottom: 8,
  },
  readMoreText: {
    fontSize: 16,
    color: '#A8C2EE',
    fontWeight: '500',
  },
  organizerContainer: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  organizerName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  organizerCategory: {
    fontSize: 14,
    color: '#666',
  },
  contactContainer: {
    gap: 12,
  },
  contactButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    backgroundColor: 'white',
    borderRadius: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  contactText: {
    fontSize: 16,
    color: '#333',
    marginLeft: 12,
  },
  reviewCard: {
    backgroundColor: 'white',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  reviewHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  reviewName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  reviewRating: {
    flexDirection: 'row',
  },
  reviewComment: {
    fontSize: 14,
    color: '#666',
    lineHeight: 20,
    marginBottom: 8,
  },
  reviewDate: {
    fontSize: 12,
    color: '#999',
  },
  viewAllReviewsButton: {
    backgroundColor: 'white',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#A8C2EE',
    marginTop: 8,
  },
  viewAllReviewsText: {
    fontSize: 16,
    color: '#A8C2EE',
    fontWeight: '500',
  },
  bottomActions: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: 'white',
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    gap: 12,
  },
  chatButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#A8C2EE',
    backgroundColor: 'white',
  },
  chatButtonText: {
    fontSize: 16,
    color: '#A8C2EE',
    fontWeight: '500',
    marginLeft: 8,
  },
  bookButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 8,
    backgroundColor: '#A8C2EE',
  },
  bookButtonText: {
    fontSize: 16,
    color: 'white',
    fontWeight: '600',
    marginLeft: 8,
  },
});