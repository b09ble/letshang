import React, { useEffect } from 'react';
import { ScrollView, View, StyleSheet, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SearchBar from '@/components/SearchBar';
import Categories from '@/components/Categories';
import AdvertBanner from '@/components/AdvertBanner';
import EventCarousel from '@/components/EventCarousel';
import EventSection from '@/components/EventSection';
import Animated, { 
  useSharedValue, 
  useAnimatedStyle, 
  withTiming,
  Easing
} from 'react-native-reanimated';

const SECTIONS = {
  freeAdmission: {
    title: 'Free Admission',
    events: [
      {
        id: '1',
        title: 'Art Gallery Opening',
        location: 'National Art Gallery',
        imageUrl: 'https://images.pexels.com/photos/1647121/pexels-photo-1647121.jpeg',
      },
      {
        id: '2',
        title: 'Street Food Festival',
        location: 'Haji Lane',
        imageUrl: 'https://images.pexels.com/photos/2608517/pexels-photo-2608517.jpeg',
      },
    ],
  },
  kidFriendly: {
    title: 'Kid Friendly',
    events: [
      {
        id: '1',
        title: 'Puppet Show',
        location: 'Children\'s Museum',
        imageUrl: 'https://images.pexels.com/photos/1449934/pexels-photo-1449934.jpeg',
      },
      {
        id: '2',
        title: 'Face Painting Festival',
        location: 'Marina Bay Sands',
        imageUrl: 'https://images.pexels.com/photos/1157557/pexels-photo-1157557.jpeg',
      },
    ],
  },
  newEvents: {
    title: 'New Events',
    events: [
      {
        id: '1',
        title: 'Tech Meetup 2025',
        location: 'Apple Orchard Road',
        imageUrl: 'https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg',
      },
      {
        id: '2',
        title: 'Sunset Yoga',
        location: 'Beachfront',
        imageUrl: 'https://images.pexels.com/photos/1051838/pexels-photo-1051838.jpeg',
      },
    ],
  },
  forFoodies: {
    title: 'For Foodies',
    events: [
      {
        id: '1',
        title: 'Wine Tasting',
        location: 'Malt & Wine Asia',
        imageUrl: 'https://images.pexels.com/photos/2702805/pexels-photo-2702805.jpeg',
      },
      {
        id: '2',
        title: 'Cooking Workshop',
        location: 'ABC Cooking Studio',
        imageUrl: 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg',
      },
    ],
  },
  forAdventurers: {
    title: 'For Adventurers',
    events: [
      {
        id: '1',
        title: 'Rock Climbing',
        location: 'Funan',
        imageUrl: 'https://images.pexels.com/photos/1822458/pexels-photo-1822458.jpeg',
      },
      {
        id: '2',
        title: 'Kayaking Trip',
        location: 'River Rapids',
        imageUrl: 'https://images.pexels.com/photos/1430677/pexels-photo-1430677.jpeg',
      },
    ],
  },
  forCreatives: {
    title: 'For Creatives',
    events: [
      {
        id: '1',
        title: 'Photography Workshop',
        location: 'DECK',
        imageUrl: 'https://images.pexels.com/photos/1793037/pexels-photo-1793037.jpeg',
      },
      {
        id: '2',
        title: 'Pottery Class',
        location: 'Artisan Workshop',
        imageUrl: 'https://images.pexels.com/photos/1498813/pexels-photo-1498813.jpeg',
      },
    ],
  },
};

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const opacity = useSharedValue(0);
  const translateY = useSharedValue(20);
  
  useEffect(() => {
    opacity.value = withTiming(1, { 
      duration: 600, 
      easing: Easing.bezier(0.25, 0.1, 0.25, 1)
    });
    
    translateY.value = withTiming(0, { 
      duration: 600, 
      easing: Easing.bezier(0.25, 0.1, 0.25, 1)
    });
  }, []);
  
  const animatedStyle = useAnimatedStyle(() => {
    return {
      opacity: opacity.value,
      transform: [{ translateY: translateY.value }],
    };
  });

  return (
    <View style={styles.container}>
      <SearchBar />
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 16 }
        ]}
      >
        <Animated.View style={animatedStyle}>
          <Categories />
          <AdvertBanner />
          <EventCarousel />
          <EventSection {...SECTIONS.freeAdmission} />
          <EventSection {...SECTIONS.kidFriendly} />
          <EventSection {...SECTIONS.newEvents} />
          <EventSection {...SECTIONS.forFoodies} />
          <EventSection {...SECTIONS.forAdventurers} />
          <EventSection {...SECTIONS.forCreatives} />
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  scrollContent: {
    paddingTop: 16,
  },
});