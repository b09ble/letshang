import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Platform,
  Linking,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  MapPin,
  Clock,
  Navigation,
  Phone,
  MessageCircle,
  ChevronRight,
  Calendar,
  Users,
} from 'lucide-react-native';

interface Booking {
  id: string;
  eventTitle: string;
  location: string;
  fullAddress: string;
  date: string;
  time: string;
  attendees: number;
  status: 'upcoming' | 'ongoing' | 'completed';
  directions: DirectionStep[];
  contactPhone?: string;
  estimatedTravelTime: string;
  transportMode: 'walking' | 'driving' | 'public';
}

interface DirectionStep {
  id: string;
  instruction: string;
  distance: string;
  duration: string;
  type: 'walk' | 'turn' | 'transport' | 'arrive';
}

const BOOKINGS: Booking[] = [
  {
    id: '1',
    eventTitle: 'Rooftop Party',
    location: 'Chinatown Heritage Centre',
    fullAddress: '48 Pagoda Street, Singapore 059207',
    date: 'Today',
    time: '7:00 PM - 12:00 AM',
    attendees: 85,
    status: 'upcoming',
    estimatedTravelTime: '25 mins',
    transportMode: 'public',
    contactPhone: '+65 6789 1234',
    directions: [
      {
        id: '1',
        instruction: 'Walk to Tanjong Pagar MRT Station',
        distance: '200m',
        duration: '3 mins',
        type: 'walk',
      },
      {
        id: '2',
        instruction: 'Take East West Line towards Pasir Ris',
        distance: '2 stations',
        duration: '6 mins',
        type: 'transport',
      },
      {
        id: '3',
        instruction: 'Alight at Raffles Place MRT Station',
        distance: '',
        duration: '1 min',
        type: 'transport',
      },
      {
        id: '4',
        instruction: 'Transfer to North South Line towards Jurong East',
        distance: '1 station',
        duration: '3 mins',
        type: 'transport',
      },
      {
        id: '5',
        instruction: 'Alight at Chinatown MRT Station (Exit A)',
        distance: '',
        duration: '1 min',
        type: 'transport',
      },
      {
        id: '6',
        instruction: 'Walk along Pagoda Street towards Heritage Centre',
        distance: '350m',
        duration: '5 mins',
        type: 'walk',
      },
      {
        id: '7',
        instruction: 'Arrive at Chinatown Heritage Centre',
        distance: '',
        duration: '',
        type: 'arrive',
      },
    ],
  },
  {
    id: '2',
    eventTitle: 'Beach Volleyball',
    location: 'Sentosa Beach',
    fullAddress: 'Siloso Beach, Sentosa Island, Singapore',
    date: 'Tomorrow',
    time: '10:00 AM - 2:00 PM',
    attendees: 24,
    status: 'upcoming',
    estimatedTravelTime: '35 mins',
    transportMode: 'public',
    contactPhone: '+65 6234 5678',
    directions: [
      {
        id: '1',
        instruction: 'Walk to nearest MRT station',
        distance: '300m',
        duration: '4 mins',
        type: 'walk',
      },
      {
        id: '2',
        instruction: 'Take MRT to HarbourFront Station',
        distance: '8 stations',
        duration: '15 mins',
        type: 'transport',
      },
      {
        id: '3',
        instruction: 'Transfer to Sentosa Express at HarbourFront',
        distance: '',
        duration: '3 mins',
        type: 'transport',
      },
      {
        id: '4',
        instruction: 'Take Sentosa Express to Beach Station',
        distance: '2 stations',
        duration: '8 mins',
        type: 'transport',
      },
      {
        id: '5',
        instruction: 'Walk to Siloso Beach volleyball courts',
        distance: '400m',
        duration: '5 mins',
        type: 'walk',
      },
      {
        id: '6',
        instruction: 'Arrive at Beach Volleyball Courts',
        distance: '',
        duration: '',
        type: 'arrive',
      },
    ],
  },
  {
    id: '3',
    eventTitle: 'Dinner Social',
    location: 'Orchard',
    fullAddress: '391 Orchard Road, Singapore 238872',
    date: 'Friday',
    time: '6:30 PM - 9:30 PM',
    attendees: 32,
    status: 'upcoming',
    estimatedTravelTime: '20 mins',
    transportMode: 'public',
    contactPhone: '+65 6345 6789',
    directions: [
      {
        id: '1',
        instruction: 'Walk to Somerset MRT Station',
        distance: '250m',
        duration: '3 mins',
        type: 'walk',
      },
      {
        id: '2',
        instruction: 'Take North South Line towards Marina South Pier',
        distance: '1 station',
        duration: '2 mins',
        type: 'transport',
      },
      {
        id: '3',
        instruction: 'Alight at Orchard MRT Station (Exit B)',
        distance: '',
        duration: '1 min',
        type: 'transport',
      },
      {
        id: '4',
        instruction: 'Walk along Orchard Road towards Takashimaya',
        distance: '200m',
        duration: '3 mins',
        type: 'walk',
      },
      {
        id: '5',
        instruction: 'Enter Takashimaya Shopping Centre',
        distance: '',
        duration: '1 min',
        type: 'walk',
      },
      {
        id: '6',
        instruction: 'Take elevator to Level 12 - Restaurant Floor',
        distance: '',
        duration: '2 mins',
        type: 'walk',
      },
      {
        id: '7',
        instruction: 'Arrive at Restaurant',
        distance: '',
        duration: '',
        type: 'arrive',
      },
    ],
  },
];

export default function BookingsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [expandedBooking, setExpandedBooking] = useState<string | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming':
        return '#A8C2EE';
      case 'ongoing':
        return '#4CAF50';
      case 'completed':
        return '#999';
      default:
        return '#A8C2EE';
    }
  };

  const getStepIcon = (type: string) => {
    switch (type) {
      case 'walk':
        return '🚶';
      case 'transport':
        return '🚇';
      case 'turn':
        return '↩️';
      case 'arrive':
        return '📍';
      default:
        return '•';
    }
  };

  const handleOpenMaps = (address: string) => {
    const encodedAddress = encodeURIComponent(address);
    const mapsUrl = Platform.select({
      ios: `maps://app?daddr=${encodedAddress}`,
      android: `google.navigation:q=${encodedAddress}`,
      web: `https://maps.google.com/maps?daddr=${encodedAddress}`,
    });
    
    if (mapsUrl) {
      Linking.openURL(mapsUrl);
    }
  };

  const handleCall = (phone: string) => {
    Linking.openURL(`tel:${phone}`);
  };

  const toggleDirections = (bookingId: string) => {
    setExpandedBooking(expandedBooking === bookingId ? null : bookingId);
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
          <ArrowLeft size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Bookings</Text>
        <View style={styles.headerSpacer} />
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {BOOKINGS.map((booking) => (
          <View key={booking.id} style={styles.bookingCard}>
            {/* Booking Header */}
            <View style={styles.bookingHeader}>
              <View style={styles.bookingInfo}>
                <Text style={styles.eventTitle}>{booking.eventTitle}</Text>
                <View style={styles.locationRow}>
                  <MapPin size={16} color="#666" />
                  <Text style={styles.locationText}>{booking.location}</Text>
                </View>
                <View style={styles.timeRow}>
                  <Clock size={16} color="#666" />
                  <Text style={styles.timeText}>{booking.date} • {booking.time}</Text>
                </View>
                <View style={styles.attendeesRow}>
                  <Users size={16} color="#666" />
                  <Text style={styles.attendeesText}>{booking.attendees} attending</Text>
                </View>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: getStatusColor(booking.status) }]}>
                <Text style={styles.statusText}>{booking.status.toUpperCase()}</Text>
              </View>
            </View>

            {/* Quick Actions */}
            <View style={styles.quickActions}>
              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => handleOpenMaps(booking.fullAddress)}
              >
                <Navigation size={18} color="#A8C2EE" />
                <Text style={styles.actionText}>Open Maps</Text>
              </TouchableOpacity>

              {booking.contactPhone && (
                <TouchableOpacity
                  style={styles.actionButton}
                  onPress={() => handleCall(booking.contactPhone!)}
                >
                  <Phone size={18} color="#A8C2EE" />
                  <Text style={styles.actionText}>Call</Text>
                </TouchableOpacity>
              )}

              <TouchableOpacity
                style={styles.actionButton}
                onPress={() => toggleDirections(booking.id)}
              >
                <MessageCircle size={18} color="#A8C2EE" />
                <Text style={styles.actionText}>Directions</Text>
                <ChevronRight 
                  size={16} 
                  color="#A8C2EE" 
                  style={[
                    styles.chevron,
                    expandedBooking === booking.id && styles.chevronExpanded
                  ]} 
                />
              </TouchableOpacity>
            </View>

            {/* Travel Info */}
            <View style={styles.travelInfo}>
              <Text style={styles.travelTime}>
                🕒 Estimated travel time: {booking.estimatedTravelTime}
              </Text>
              <Text style={styles.transportMode}>
                {booking.transportMode === 'public' && '🚇 Public Transport'}
                {booking.transportMode === 'walking' && '🚶 Walking'}
                {booking.transportMode === 'driving' && '🚗 Driving'}
              </Text>
            </View>

            {/* Step-by-step Directions */}
            {expandedBooking === booking.id && (
              <View style={styles.directionsContainer}>
                <Text style={styles.directionsTitle}>Step-by-step Directions</Text>
                {booking.directions.map((step, index) => (
                  <View key={step.id} style={styles.directionStep}>
                    <View style={styles.stepNumber}>
                      <Text style={styles.stepIcon}>{getStepIcon(step.type)}</Text>
                    </View>
                    <View style={styles.stepContent}>
                      <Text style={styles.stepInstruction}>{step.instruction}</Text>
                      {(step.distance || step.duration) && (
                        <Text style={styles.stepDetails}>
                          {step.distance && `${step.distance}`}
                          {step.distance && step.duration && ' • '}
                          {step.duration && `${step.duration}`}
                        </Text>
                      )}
                    </View>
                  </View>
                ))}
                
                <TouchableOpacity
                  style={styles.startNavigationButton}
                  onPress={() => handleOpenMaps(booking.fullAddress)}
                >
                  <Navigation size={20} color="white" />
                  <Text style={styles.startNavigationText}>Start Navigation</Text>
                </TouchableOpacity>
              </View>
            )}
          </View>
        ))}

        {BOOKINGS.length === 0 && (
          <View style={styles.emptyState}>
            <Calendar size={48} color="#ccc" />
            <Text style={styles.emptyTitle}>No Bookings Yet</Text>
            <Text style={styles.emptyText}>
              Your upcoming event bookings will appear here
            </Text>
          </View>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F8FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  bookingCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  bookingInfo: {
    flex: 1,
  },
  eventTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  locationText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  timeText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  attendeesRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  attendeesText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  statusText: {
    fontSize: 12,
    color: 'white',
    fontWeight: '600',
  },
  quickActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 8,
  },
  actionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: '#F5F8FF',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#D1DFFA',
  },
  actionText: {
    fontSize: 14,
    color: '#A8C2EE',
    fontWeight: '500',
    marginLeft: 6,
  },
  chevron: {
    marginLeft: 4,
    transform: [{ rotate: '0deg' }],
  },
  chevronExpanded: {
    transform: [{ rotate: '90deg' }],
  },
  travelInfo: {
    backgroundColor: '#F5F8FF',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  travelTime: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
    marginBottom: 4,
  },
  transportMode: {
    fontSize: 14,
    color: '#666',
  },
  directionsContainer: {
    borderTopWidth: 1,
    borderTopColor: '#E0E0E0',
    paddingTop: 16,
  },
  directionsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  directionStep: {
    flexDirection: 'row',
    marginBottom: 12,
    alignItems: 'flex-start',
  },
  stepNumber: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F5F8FF',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  stepIcon: {
    fontSize: 16,
  },
  stepContent: {
    flex: 1,
    paddingTop: 2,
  },
  stepInstruction: {
    fontSize: 14,
    color: '#333',
    fontWeight: '500',
    marginBottom: 2,
  },
  stepDetails: {
    fontSize: 12,
    color: '#666',
  },
  startNavigationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#A8C2EE',
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 16,
  },
  startNavigationText: {
    fontSize: 16,
    color: 'white',
    fontWeight: '600',
    marginLeft: 8,
  },
  emptyState: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    lineHeight: 22,
  },
});