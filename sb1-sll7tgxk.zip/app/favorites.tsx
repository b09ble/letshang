import React from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { MapPin, Clock, Users } from 'lucide-react-native';

type FavoriteEvent = {
  id: string;
  title: string;
  location: string;
  time: string;
  attendees: number;
  imageUrl: string;
};

const FAVORITES: FavoriteEvent[] = [
  {
    id: '1',
    title: 'Rooftop Party',
    location: 'Chinatown Heritage Centre',
    time: 'Sat, Jun 21 • 7:00 PM',
    attendees: 85,
    imageUrl: 'https://images.pexels.com/photos/2788488/pexels-photo-2788488.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '2',
    title: 'Beach Volleyball',
    location: 'Sentosa Beach',
    time: 'Sun, Jun 22 • 10:00 AM',
    attendees: 24,
    imageUrl: 'https://images.pexels.com/photos/1263426/pexels-photo-1263426.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
  {
    id: '3',
    title: 'Dinner Social',
    location: 'Orchard',
    time: 'Fri, Jun 20 • 6:30 PM',
    attendees: 32,
    imageUrl: 'https://images.pexels.com/photos/696218/pexels-photo-696218.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2'
  },
];

export default function FavoritesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const handleEventPress = (eventId: string) => {
    router.push(`/event/${eventId}`);
  };

  const renderItem = ({ item }: { item: FavoriteEvent }) => (
    <TouchableOpacity 
      style={styles.eventCard}
      onPress={() => handleEventPress(item.id)}
    >
      <Image source={{ uri: item.imageUrl }} style={styles.eventImage} />
      <View style={styles.eventContent}>
        <Text style={styles.eventTitle}>{item.title}</Text>
        
        <View style={styles.eventDetail}>
          <MapPin size={14} color="#666" style={styles.icon} />
          <Text style={styles.eventDetailText}>{item.location}</Text>
        </View>
        
        <View style={styles.eventDetail}>
          <Clock size={14} color="#666" style={styles.icon} />
          <Text style={styles.eventDetailText}>{item.time}</Text>
        </View>
        
        <View style={styles.eventDetail}>
          <Users size={14} color="#666" style={styles.icon} />
          <Text style={styles.eventDetailText}>{item.attendees} attending</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={FAVORITES}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: insets.bottom + 20 }
        ]}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <Text style={styles.header}>Your Favourite Events</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  header: {
    fontSize: 22,
    fontWeight: '600',
    color: '#333',
    marginBottom: 20,
    paddingHorizontal: 16,
  },
  listContent: {
    paddingTop: 20,
    paddingHorizontal: 16,
  },
  eventCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginBottom: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  eventImage: {
    width: '100%',
    height: 160,
    resizeMode: 'cover',
  },
  eventContent: {
    padding: 16,
  },
  eventTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 10,
  },
  eventDetail: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  icon: {
    marginRight: 8,
  },
  eventDetailText: {
    fontSize: 14,
    color: '#666',
  },
});