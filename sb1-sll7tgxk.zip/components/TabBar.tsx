import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';
import Animated, {
  useAnimatedStyle,
  withTiming,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Footprints, Heart, User } from 'lucide-react-native';

export default function TabBar({ state, descriptors, navigation }: BottomTabBarProps) {
  const insets = useSafeAreaInsets();
  const scale = useSharedValue(1);

  const getTabIcon = (routeName: string, isFocused: boolean) => {
    const color = isFocused ? '#FFFFFF' : '#EBF1FB';
    
    switch (routeName) {
      case 'home':
        return null; // No icon shown in tab bar for home
      case 'following':
        return <Footprints size={24} color={color} />;
      case 'favorites':
        return <Heart size={24} color={color} />;
      case 'me':
        return <User size={24} color={color} />;
      default:
        return null;
    }
  };

  // Filter out the home tab and other tabs not meant to be shown in the tab bar
  const visibleRoutes = state.routes.filter(
    route => ['following', 'favorites', 'me'].includes(route.name)
  );

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      {visibleRoutes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label = options.tabBarLabel || options.title || route.name;
        const isFocused = state.routes[state.index].name === route.name;

        const onPress = () => {
          scale.value = withSpring(1.2, {}, () => {
            scale.value = withSpring(1);
          });
          
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        return (
          <TouchableOpacity
            key={route.key}
            accessibilityRole="button"
            accessibilityState={isFocused ? { selected: true } : {}}
            accessibilityLabel={options.tabBarAccessibilityLabel}
            testID={options.tabBarTestID}
            onPress={onPress}
            style={styles.tab}
          >
            <View style={styles.tabContent}>
              {getTabIcon(route.name, isFocused)}
              <Text style={[
                styles.label,
                isFocused && styles.labelFocused,
                styles.labelSpacing
              ]}>
                {label.toString()}
              </Text>
            </View>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: '#A8C2EE',
    height: 70,
  },
  tab: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabContent: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: 20, // Added padding to move content down
  },
  label: {
    fontSize: 12,
    marginTop: 3, // Increased from 4 to create more space
    color: '#EBF1FB',
    fontWeight: '400',
  },
  labelFocused: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
  labelSpacing: {
    paddingTop: 2, // Additional padding for text
  },
});