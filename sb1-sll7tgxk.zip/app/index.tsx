import React from 'react';
import { Redirect } from 'expo-router';

// Redirect to the home page in tabs
export default function Index() {
  return <Redirect href="/home" />;
}