import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';
import { usePathname, useRouter } from 'expo-router';
import { AlignJustify, Calendar, Users } from 'lucide-react-native';
import SideDrawer from './SideDrawer';

export default function HeaderBar() {
  const pathname = usePathname();
  const router = useRouter();
  const [showDrawer, setShowDrawer] = useState(false);
  
  // Show back button for any screen that's not the home screen
  const isHomeScreen = pathname === '/home';
  
  const handleCalendarPress = () => {
    router.push('/bookings');
  };
  
  const handleFriendsPress = () => {
    router.push('/friends');
  };

  const handleMenuPress = () => {
    setShowDrawer(true);
  };
  
  return (
    <>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.leftContainer}>
            {isHomeScreen ? (
              <TouchableOpacity style={styles.iconButton} onPress={handleMenuPress}>
                <AlignJustify color="white" size={24} />
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                style={styles.iconButton}
                onPress={() => router.push('/home')}
              >
                <Text style={styles.backButton}>←</Text>
              </TouchableOpacity>
            )}
          </View>
          
          <Text style={styles.title}>Lets Hang!</Text>
          
          <View style={styles.rightContainer}>
            <TouchableOpacity style={styles.iconButton} onPress={handleCalendarPress}>
              <Calendar color="white" size={24} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton} onPress={handleFriendsPress}>
              <Users color="white" size={24} />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <SideDrawer 
        visible={showDrawer} 
        onClose={() => setShowDrawer(false)} 
      />
    </>
  );
}

const styles = StyleSheet.create({
  header: {
    backgroundColor: '#A8C2EE',
    height: Platform.OS === 'ios' ? 100 : 80,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    paddingTop: Platform.OS === 'ios' ? 60 : 30, // Increased by 10px
    flex: 1,
  },
  leftContainer: {
    width: 80,
    alignItems: 'flex-start',
  },
  rightContainer: {
    width: 80,
    flexDirection: 'row',
    justifyContent: 'flex-end',
    gap: 10,
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    color: 'white',
  },
  iconButton: {
    padding: 5,
  },
  backButton: {
    fontSize: 24,
    color: 'white',
    fontWeight: 'bold',
  }
});