import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Settings, UserPlus, Calendar, MapPin, Heart, Clock, MessageCircle } from 'lucide-react-native';

export default function MeScreen() {
  const insets = useSafeAreaInsets();

  return (
    <ScrollView 
      style={styles.container}
      contentContainerStyle={[
        styles.scrollContent,
        { paddingBottom: insets.bottom + 20 }
      ]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.profileHeader}>
        <Image 
          source={{ uri: 'https://images.pexels.com/photos/1821095/pexels-photo-1821095.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' }} 
          style={styles.profileImage} 
        />
        
        <View style={styles.profileNameContainer}>
          <Text style={styles.profileName}>Jessica Williams</Text>
          <Text style={styles.profileLocation}>Newton, Singapore</Text>
        </View>
        
        <TouchableOpacity style={styles.settingsButton}>
          <Settings size={22} color="#666" />
        </TouchableOpacity>
      </View>
      
      <View style={styles.statsContainer}>
        <View style={styles.statItem}>
          <Text style={styles.statValue}>128</Text>
          <Text style={styles.statLabel}>Events</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>86</Text>
          <Text style={styles.statLabel}>Following</Text>
        </View>
        <View style={styles.statDivider} />
        <View style={styles.statItem}>
          <Text style={styles.statValue}>214</Text>
          <Text style={styles.statLabel}>Followers</Text>
        </View>
      </View>
      
      <View style={styles.actionButtonsContainer}>
        <TouchableOpacity style={styles.actionButton}>
          <Calendar size={20} color="#A8C2EE" />
          <Text style={styles.actionButtonText}>My Events</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.actionButton}>
          <UserPlus size={20} color="#A8C2EE" />
          <Text style={styles.actionButtonText}>Find Friends</Text>
        </TouchableOpacity>
      </View>
      
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Upcoming Events</Text>
        
        <TouchableOpacity style={styles.eventCard}>
          <View style={styles.eventCardContent}>
            <View style={styles.eventDateBox}>
              <Text style={styles.eventDateDay}>18</Text>
              <Text style={styles.eventDateMonth}>JUN</Text>
            </View>
            
            <View style={styles.eventDetails}>
              <Text style={styles.eventTitle}>Karaoke Night</Text>
              <View style={styles.eventDetailRow}>
                <MapPin size={14} color="#666" style={styles.eventDetailIcon} />
                <Text style={styles.eventDetailText}>Sing Your Heart Out, 313@Somerset</Text>
              </View>
              <View style={styles.eventDetailRow}>
                <Clock size={14} color="#666" style={styles.eventDetailIcon} />
                <Text style={styles.eventDetailText}>8:00 PM - 11:00 PM</Text>
              </View>
            </View>
          </View>
          
          <View style={styles.eventActions}>
            <TouchableOpacity style={styles.eventAction}>
              <MessageCircle size={18} color="#A8C2EE" />
              <Text style={styles.eventActionText}>Chat</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.eventAction}>
              <Heart size={18} color="#A8C2EE" />
              <Text style={styles.eventActionText}>Favorite</Text>
            </TouchableOpacity>
          </View>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  scrollContent: {
    padding: 16,
  },
  profileHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 24,
  },
  profileImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  profileNameContainer: {
    flex: 1,
    marginLeft: 16,
  },
  profileName: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  profileLocation: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  settingsButton: {
    padding: 8,
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    height: '80%',
    backgroundColor: '#E0E0E0',
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    width: '48%',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '500',
    color: '#333',
    marginLeft: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  eventCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  eventCardContent: {
    flexDirection: 'row',
    padding: 16,
  },
  eventDateBox: {
    width: 50,
    height: 60,
    backgroundColor: '#A8C2EE',
    borderRadius: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  eventDateDay: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'white',
  },
  eventDateMonth: {
    fontSize: 12,
    color: 'white',
  },
  eventDetails: {
    marginLeft: 16,
    flex: 1,
  },
  eventTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 8,
  },
  eventDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  eventDetailIcon: {
    marginRight: 6,
  },
  eventDetailText: {
    fontSize: 13,
    color: '#666',
  },
  eventActions: {
    flexDirection: 'row',
    borderTopWidth: 1,
    borderTopColor: '#EFEFEF',
  },
  eventAction: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  eventActionText: {
    marginLeft: 6,
    fontSize: 14,
    color: '#666',
  },
});