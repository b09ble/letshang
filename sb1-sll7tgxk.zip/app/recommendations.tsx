import React, { useState, useCallback, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  Dimensions,
  Platform,
  TouchableOpacity,
  StatusBar,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withTiming,
  interpolate,
  runOnJS,
  useAnimatedGestureHandler,
  Extrapolate,
} from 'react-native-reanimated';
import {
  PanGestureHandler,
  PanGestureHandlerGestureEvent,
} from 'react-native-gesture-handler';
import {
  ArrowLeft,
  Heart,
  X,
  MapPin,
  Clock,
  Users,
  Star,
  Zap,
  RotateCcw,
} from 'lucide-react-native';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');
const CARD_WIDTH = SCREEN_WIDTH * 0.9;
const CARD_HEIGHT = SCREEN_HEIGHT * 0.7;
const SWIPE_THRESHOLD = SCREEN_WIDTH * 0.25;

interface ActivityProfile {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  location: string;
  distance: string;
  duration: string;
  groupSize: string;
  difficulty: 'Easy' | 'Moderate' | 'Challenging';
  category: string;
  price: string;
  rating: number;
  reviewCount: number;
  images: string[];
  highlights: string[];
  organizer: {
    name: string;
    avatar: string;
    verified: boolean;
  };
  nextAvailable: string;
  spotsLeft: number;
}

const ACTIVITY_PROFILES: ActivityProfile[] = [
  {
    id: '1',
    title: 'Sunset Rooftop Yoga',
    description: 'Find your zen with panoramic city views as the sun sets over Singapore\'s skyline.',
    longDescription: 'Join us for a transformative yoga experience high above the bustling city. Our certified instructors will guide you through a gentle flow sequence designed for all levels, while you enjoy breathtaking 360-degree views of Singapore. The session includes meditation, breathing exercises, and complimentary herbal tea.',
    location: 'Marina Bay Sands SkyPark',
    distance: '2.3 km',
    duration: '90 mins',
    groupSize: '8-15 people',
    difficulty: 'Easy',
    category: 'Wellness & Mindfulness',
    price: '$45',
    rating: 4.9,
    reviewCount: 127,
    images: [
      'https://images.pexels.com/photos/1051838/pexels-photo-1051838.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3822622/pexels-photo-3822622.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/3823039/pexels-photo-3823039.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ],
    highlights: ['Certified Instructors', 'All Levels Welcome', 'Stunning Views', 'Herbal Tea Included'],
    organizer: {
      name: 'Zen Wellness Studio',
      avatar: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      verified: true,
    },
    nextAvailable: 'Today 6:30 PM',
    spotsLeft: 3,
  },
  {
    id: '2',
    title: 'Street Food Adventure',
    description: 'Discover Singapore\'s hidden culinary gems with a local foodie guide through authentic hawker centers.',
    longDescription: 'Embark on a gastronomic journey through Singapore\'s most authentic hawker centers and street food stalls. Our local food expert will introduce you to traditional dishes, share stories about their origins, and help you navigate the bustling food scene like a true local. Includes tastings at 6-8 different stalls.',
    location: 'Chinatown Complex',
    distance: '1.8 km',
    duration: '3 hours',
    groupSize: '4-8 people',
    difficulty: 'Easy',
    category: 'Food & Culture',
    price: '$65',
    rating: 4.8,
    reviewCount: 203,
    images: [
      'https://images.pexels.com/photos/2608517/pexels-photo-2608517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1199957/pexels-photo-1199957.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ],
    highlights: ['Local Expert Guide', '6-8 Food Tastings', 'Cultural Stories', 'Hidden Gems'],
    organizer: {
      name: 'Singapore Food Tours',
      avatar: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      verified: true,
    },
    nextAvailable: 'Tomorrow 11:00 AM',
    spotsLeft: 2,
  },
  {
    id: '3',
    title: 'Urban Rock Climbing',
    description: 'Challenge yourself on Singapore\'s premier indoor climbing walls with expert instruction and safety gear.',
    longDescription: 'Push your limits at Singapore\'s most advanced climbing facility. Whether you\'re a beginner or experienced climber, our certified instructors will help you tackle routes suited to your skill level. All safety equipment provided, plus technique workshops and route planning sessions.',
    location: 'Onsight Climbing Gym',
    distance: '3.1 km',
    duration: '2.5 hours',
    groupSize: '6-12 people',
    difficulty: 'Moderate',
    category: 'Adventure & Sports',
    price: '$55',
    rating: 4.7,
    reviewCount: 89,
    images: [
      'https://images.pexels.com/photos/1822458/pexels-photo-1822458.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/7688336/pexels-photo-7688336.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/7688460/pexels-photo-7688460.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ],
    highlights: ['Expert Instruction', 'All Equipment Included', 'Multiple Difficulty Levels', 'Safety First'],
    organizer: {
      name: 'Adventure Singapore',
      avatar: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      verified: true,
    },
    nextAvailable: 'Saturday 2:00 PM',
    spotsLeft: 5,
  },
  {
    id: '4',
    title: 'Photography Workshop',
    description: 'Master the art of urban photography while exploring Singapore\'s most photogenic neighborhoods.',
    longDescription: 'Learn professional photography techniques while capturing Singapore\'s stunning architecture and street life. This hands-on workshop covers composition, lighting, and post-processing techniques. Suitable for all camera types including smartphones. Includes photo review session and digital editing tips.',
    location: 'Kampong Glam District',
    distance: '2.7 km',
    duration: '4 hours',
    groupSize: '5-10 people',
    difficulty: 'Easy',
    category: 'Arts & Creativity',
    price: '$85',
    rating: 4.9,
    reviewCount: 156,
    images: [
      'https://images.pexels.com/photos/1793037/pexels-photo-1793037.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1264210/pexels-photo-1264210.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1983032/pexels-photo-1983032.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ],
    highlights: ['Professional Instruction', 'All Skill Levels', 'Photo Review Session', 'Editing Tips'],
    organizer: {
      name: 'Singapore Photo Academy',
      avatar: 'https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      verified: true,
    },
    nextAvailable: 'Sunday 9:00 AM',
    spotsLeft: 1,
  },
  {
    id: '5',
    title: 'Cocktail Masterclass',
    description: 'Learn to craft signature cocktails from award-winning mixologists in an intimate speakeasy setting.',
    longDescription: 'Step into the world of craft cocktails with Singapore\'s top bartenders. Learn the secrets behind classic and contemporary cocktails, from proper muddling techniques to creative garnish artistry. Includes hands-on mixing, tasting sessions, and recipe cards to take home.',
    location: 'Atlas Bar, Parkview Square',
    distance: '1.5 km',
    duration: '2 hours',
    groupSize: '8-16 people',
    difficulty: 'Easy',
    category: 'Food & Nightlife',
    price: '$95',
    rating: 4.8,
    reviewCount: 94,
    images: [
      'https://images.pexels.com/photos/2702805/pexels-photo-2702805.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1304540/pexels-photo-1304540.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      'https://images.pexels.com/photos/1170599/pexels-photo-1170599.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    ],
    highlights: ['Award-Winning Mixologists', 'Hands-On Learning', 'Recipe Cards Included', 'Premium Spirits'],
    organizer: {
      name: 'Singapore Cocktail Society',
      avatar: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      verified: true,
    },
    nextAvailable: 'Friday 7:00 PM',
    spotsLeft: 4,
  },
];

const AnimatedPanGestureHandler = Animated.createAnimatedComponent(PanGestureHandler);

export default function MatchAndHangScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [likedActivities, setLikedActivities] = useState<string[]>([]);
  const [passedActivities, setPassedActivities] = useState<string[]>([]);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  // Animation values
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const rotate = useSharedValue(0);
  const scale = useSharedValue(1);
  const nextCardScale = useSharedValue(0.95);
  const nextCardOpacity = useSharedValue(0.8);

  const resetCard = useCallback(() => {
    'worklet';
    translateX.value = withSpring(0);
    translateY.value = withSpring(0);
    rotate.value = withSpring(0);
    scale.value = withSpring(1);
    nextCardScale.value = withSpring(0.95);
    nextCardOpacity.value = withSpring(0.8);
  }, []);

  const handleSwipeComplete = useCallback((direction: 'left' | 'right') => {
    const currentActivity = ACTIVITY_PROFILES[currentIndex];
    if (!currentActivity) return;

    if (direction === 'right') {
      setLikedActivities(prev => [...prev, currentActivity.id]);
    } else {
      setPassedActivities(prev => [...prev, currentActivity.id]);
    }

    // Move to next card
    setCurrentIndex(prev => {
      const nextIndex = prev + 1;
      if (nextIndex >= ACTIVITY_PROFILES.length) {
        // All cards swiped, navigate back or show completion screen
        router.back();
        return prev;
      }
      return nextIndex;
    });

    // Reset image index for next card
    setCurrentImageIndex(0);

    // Reset animations
    translateX.value = 0;
    translateY.value = 0;
    rotate.value = 0;
    scale.value = 1;
    nextCardScale.value = 0.95;
    nextCardOpacity.value = 0.8;
  }, [currentIndex, router]);

  const gestureHandler = useAnimatedGestureHandler<PanGestureHandlerGestureEvent>({
    onStart: () => {
      scale.value = withSpring(1.05);
    },
    onActive: (event) => {
      translateX.value = event.translationX;
      translateY.value = event.translationY * 0.5;
      
      const rotation = interpolate(
        event.translationX,
        [-SCREEN_WIDTH / 2, 0, SCREEN_WIDTH / 2],
        [-15, 0, 15],
        Extrapolate.CLAMP
      );
      rotate.value = rotation;

      // Animate next card
      const progress = Math.min(Math.abs(event.translationX) / SCREEN_WIDTH, 1);
      nextCardScale.value = interpolate(progress, [0, 1], [0.95, 1], Extrapolate.CLAMP);
      nextCardOpacity.value = interpolate(progress, [0, 1], [0.8, 1], Extrapolate.CLAMP);
    },
    onEnd: (event) => {
      const shouldSwipe = Math.abs(event.translationX) > SWIPE_THRESHOLD || Math.abs(event.velocityX) > 800;
      
      if (shouldSwipe) {
        const direction = event.translationX > 0 ? 'right' : 'left';
        const targetX = direction === 'right' ? SCREEN_WIDTH * 1.5 : -SCREEN_WIDTH * 1.5;
        
        translateX.value = withTiming(targetX, { duration: 300 });
        rotate.value = withTiming(direction === 'right' ? 30 : -30, { duration: 300 });
        scale.value = withTiming(0.8, { duration: 300 }, () => {
          runOnJS(handleSwipeComplete)(direction);
        });
      } else {
        resetCard();
      }
    },
  });

  const cardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { rotate: `${rotate.value}deg` },
      { scale: scale.value },
    ],
  }));

  const nextCardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: nextCardScale.value }],
    opacity: nextCardOpacity.value,
  }));

  const likeOverlayStyle = useAnimatedStyle(() => ({
    opacity: interpolate(
      translateX.value,
      [0, SWIPE_THRESHOLD],
      [0, 1],
      Extrapolate.CLAMP
    ),
  }));

  const passOverlayStyle = useAnimatedStyle(() => ({
    opacity: interpolate(
      translateX.value,
      [-SWIPE_THRESHOLD, 0],
      [1, 0],
      Extrapolate.CLAMP
    ),
  }));

  const handleLike = () => {
    translateX.value = withTiming(SCREEN_WIDTH * 1.5, { duration: 300 });
    rotate.value = withTiming(30, { duration: 300 });
    scale.value = withTiming(0.8, { duration: 300 }, () => {
      runOnJS(handleSwipeComplete)('right');
    });
  };

  const handlePass = () => {
    translateX.value = withTiming(-SCREEN_WIDTH * 1.5, { duration: 300 });
    rotate.value = withTiming(-30, { duration: 300 });
    scale.value = withTiming(0.8, { duration: 300 }, () => {
      runOnJS(handleSwipeComplete)('left');
    });
  };

  const handleUndo = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setCurrentImageIndex(0);
      // Remove last action from history
      setLikedActivities(prev => prev.slice(0, -1));
      setPassedActivities(prev => prev.slice(0, -1));
    }
  };

  const nextImage = () => {
    const currentActivity = ACTIVITY_PROFILES[currentIndex];
    if (currentActivity && currentImageIndex < currentActivity.images.length - 1) {
      setCurrentImageIndex(prev => prev + 1);
    }
  };

  const prevImage = () => {
    if (currentImageIndex > 0) {
      setCurrentImageIndex(prev => prev - 1);
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return '#4CAF50';
      case 'Moderate': return '#FF9800';
      case 'Challenging': return '#F44336';
      default: return '#666';
    }
  };

  const renderCard = (activity: ActivityProfile, isNext = false) => {
    const cardStyle = isNext ? nextCardAnimatedStyle : cardAnimatedStyle;
    const imageIndex = isNext ? 0 : currentImageIndex;

    return (
      <Animated.View style={[styles.card, cardStyle]} key={activity.id}>
        {/* Image Section */}
        <View style={styles.imageContainer}>
          <TouchableOpacity
            style={styles.imageLeftTap}
            onPress={prevImage}
            disabled={isNext}
          />
          <TouchableOpacity
            style={styles.imageRightTap}
            onPress={nextImage}
            disabled={isNext}
          />
          
          <Image
            source={{ uri: activity.images[imageIndex] }}
            style={styles.cardImage}
            resizeMode="cover"
          />
          
          {/* Image Indicators */}
          <View style={styles.imageIndicators}>
            {activity.images.map((_, index) => (
              <View
                key={index}
                style={[
                  styles.imageIndicator,
                  index === imageIndex && styles.imageIndicatorActive,
                ]}
              />
            ))}
          </View>

          {/* Overlays */}
          {!isNext && (
            <>
              <Animated.View style={[styles.overlay, styles.likeOverlay, likeOverlayStyle]}>
                <View style={styles.overlayContent}>
                  <Heart size={60} color="white" fill="white" />
                  <Text style={styles.overlayText}>LOVE IT!</Text>
                </View>
              </Animated.View>

              <Animated.View style={[styles.overlay, styles.passOverlay, passOverlayStyle]}>
                <View style={styles.overlayContent}>
                  <X size={60} color="white" />
                  <Text style={styles.overlayText}>PASS</Text>
                </View>
              </Animated.View>
            </>
          )}

          {/* Spots Left Badge */}
          {activity.spotsLeft <= 3 && (
            <View style={styles.spotsLeftBadge}>
              <Zap size={14} color="white" />
              <Text style={styles.spotsLeftText}>
                {activity.spotsLeft} spot{activity.spotsLeft !== 1 ? 's' : ''} left!
              </Text>
            </View>
          )}
        </View>

        {/* Content Section */}
        <View style={styles.cardContent}>
          <View style={styles.cardHeader}>
            <View style={styles.titleSection}>
              <Text style={styles.cardTitle}>{activity.title}</Text>
              <View style={styles.ratingContainer}>
                <Star size={16} color="#FFD700" fill="#FFD700" />
                <Text style={styles.ratingText}>{activity.rating}</Text>
                <Text style={styles.reviewCount}>({activity.reviewCount})</Text>
              </View>
            </View>
            <View style={styles.priceContainer}>
              <Text style={styles.priceText}>{activity.price}</Text>
            </View>
          </View>

          <Text style={styles.cardDescription}>{activity.description}</Text>

          <View style={styles.detailsGrid}>
            <View style={styles.detailItem}>
              <MapPin size={16} color="#666" />
              <Text style={styles.detailText}>{activity.distance}</Text>
            </View>
            <View style={styles.detailItem}>
              <Clock size={16} color="#666" />
              <Text style={styles.detailText}>{activity.duration}</Text>
            </View>
            <View style={styles.detailItem}>
              <Users size={16} color="#666" />
              <Text style={styles.detailText}>{activity.groupSize}</Text>
            </View>
            <View style={styles.detailItem}>
              <View style={[styles.difficultyDot, { backgroundColor: getDifficultyColor(activity.difficulty) }]} />
              <Text style={styles.detailText}>{activity.difficulty}</Text>
            </View>
          </View>

          <View style={styles.highlightsContainer}>
            {activity.highlights.slice(0, 3).map((highlight, index) => (
              <View key={index} style={styles.highlightTag}>
                <Text style={styles.highlightText}>{highlight}</Text>
              </View>
            ))}
          </View>

          <View style={styles.organizerSection}>
            <Image source={{ uri: activity.organizer.avatar }} style={styles.organizerAvatar} />
            <View style={styles.organizerInfo}>
              <View style={styles.organizerNameContainer}>
                <Text style={styles.organizerName}>{activity.organizer.name}</Text>
                {activity.organizer.verified && (
                  <View style={styles.verifiedBadge}>
                    <Text style={styles.verifiedText}>✓</Text>
                  </View>
                )}
              </View>
              <Text style={styles.nextAvailable}>Next: {activity.nextAvailable}</Text>
            </View>
          </View>
        </View>
      </Animated.View>
    );
  };

  if (currentIndex >= ACTIVITY_PROFILES.length) {
    return (
      <View style={[styles.container, styles.completionContainer]}>
        <StatusBar barStyle="light-content" />
        <Text style={styles.completionTitle}>All Done! 🎉</Text>
        <Text style={styles.completionText}>
          You've explored all available activities. Check your liked activities in your profile!
        </Text>
        <TouchableOpacity style={styles.completionButton} onPress={() => router.back()}>
          <Text style={styles.completionButtonText}>Back to Home</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const currentActivity = ACTIVITY_PROFILES[currentIndex];
  const nextActivity = ACTIVITY_PROFILES[currentIndex + 1];

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
          <ArrowLeft size={24} color="white" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Match & Hang</Text>
        <TouchableOpacity 
          onPress={handleUndo} 
          style={[styles.headerButton, currentIndex === 0 && styles.headerButtonDisabled]}
          disabled={currentIndex === 0}
        >
          <RotateCcw size={24} color={currentIndex === 0 ? 'rgba(255,255,255,0.3)' : 'white'} />
        </TouchableOpacity>
      </View>

      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View 
            style={[
              styles.progressFill, 
              { width: `${((currentIndex + 1) / ACTIVITY_PROFILES.length) * 100}%` }
            ]} 
          />
        </View>
        <Text style={styles.progressText}>
          {currentIndex + 1} of {ACTIVITY_PROFILES.length}
        </Text>
      </View>

      {/* Cards Container */}
      <View style={styles.cardsContainer}>
        {/* Next Card */}
        {nextActivity && (
          <View style={styles.nextCardContainer}>
            {renderCard(nextActivity, true)}
          </View>
        )}

        {/* Current Card */}
        <AnimatedPanGestureHandler onGestureEvent={gestureHandler}>
          <View style={styles.currentCardContainer}>
            {renderCard(currentActivity)}
          </View>
        </AnimatedPanGestureHandler>
      </View>

      {/* Action Buttons */}
      <View style={[styles.actionButtons, { paddingBottom: insets.bottom + 20 }]}>
        <TouchableOpacity style={styles.passButton} onPress={handlePass}>
          <X size={32} color="white" />
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.likeButton} onPress={handleLike}>
          <Heart size={32} color="white" />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#1A1A2E',
  },
  completionContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  completionTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: 'white',
    marginBottom: 16,
    textAlign: 'center',
  },
  completionText: {
    fontSize: 18,
    color: 'rgba(255,255,255,0.8)',
    textAlign: 'center',
    lineHeight: 26,
    marginBottom: 40,
  },
  completionButton: {
    backgroundColor: '#A8C2EE',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 25,
  },
  completionButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 10,
  },
  headerButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerButtonDisabled: {
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: 'white',
  },
  progressContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  progressBar: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    marginBottom: 8,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#A8C2EE',
    borderRadius: 2,
  },
  progressText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
  },
  cardsContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  currentCardContainer: {
    position: 'absolute',
  },
  nextCardContainer: {
    position: 'absolute',
  },
  card: {
    width: CARD_WIDTH,
    height: CARD_HEIGHT,
    backgroundColor: 'white',
    borderRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 10,
    overflow: 'hidden',
  },
  imageContainer: {
    height: '60%',
    position: 'relative',
  },
  imageLeftTap: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: '50%',
    zIndex: 10,
  },
  imageRightTap: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: '50%',
    zIndex: 10,
  },
  cardImage: {
    width: '100%',
    height: '100%',
  },
  imageIndicators: {
    position: 'absolute',
    top: 16,
    left: 16,
    right: 16,
    flexDirection: 'row',
    gap: 6,
  },
  imageIndicator: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(255,255,255,0.3)',
    borderRadius: 2,
  },
  imageIndicatorActive: {
    backgroundColor: 'white',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  likeOverlay: {
    backgroundColor: 'rgba(76, 175, 80, 0.9)',
  },
  passOverlay: {
    backgroundColor: 'rgba(244, 67, 54, 0.9)',
  },
  overlayContent: {
    alignItems: 'center',
  },
  overlayText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: 'white',
    marginTop: 12,
    letterSpacing: 2,
  },
  spotsLeftBadge: {
    position: 'absolute',
    top: 16,
    right: 16,
    backgroundColor: '#FF4444',
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
    gap: 4,
  },
  spotsLeftText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  cardContent: {
    flex: 1,
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  titleSection: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginBottom: 6,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  reviewCount: {
    fontSize: 14,
    color: '#666',
  },
  priceContainer: {
    backgroundColor: '#A8C2EE',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
  },
  priceText: {
    fontSize: 16,
    fontWeight: '700',
    color: 'white',
  },
  cardDescription: {
    fontSize: 16,
    color: '#555',
    lineHeight: 24,
    marginBottom: 16,
  },
  detailsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    minWidth: '45%',
  },
  detailText: {
    fontSize: 14,
    color: '#666',
    fontWeight: '500',
  },
  difficultyDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  highlightsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  highlightTag: {
    backgroundColor: '#F5F8FF',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#D1DFFA',
  },
  highlightText: {
    fontSize: 12,
    color: '#A8C2EE',
    fontWeight: '600',
  },
  organizerSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  organizerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
  },
  organizerInfo: {
    flex: 1,
  },
  organizerNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  organizerName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  verifiedBadge: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
  },
  verifiedText: {
    fontSize: 10,
    color: 'white',
    fontWeight: 'bold',
  },
  nextAvailable: {
    fontSize: 12,
    color: '#666',
    marginTop: 2,
  },
  actionButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    gap: 40,
  },
  passButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#FF4444',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#FF4444',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  likeButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: '#4CAF50',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#4CAF50',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
});