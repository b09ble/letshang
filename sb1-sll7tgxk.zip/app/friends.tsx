import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Platform,
} from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  ArrowLeft,
  UserPlus,
  MessageCircle,
  Users,
  Search,
  Filter,
  Check,
  MapPin,
  Clock,
  Calendar,
} from 'lucide-react-native';

interface Friend {
  id: string;
  name: string;
  profileImage: string;
  mutualFriends: number;
  lastActivity: string;
  status: 'online' | 'offline';
}

interface FriendRecommendation {
  id: string;
  name: string;
  profileImage: string;
  reason: string;
  mutualFriends: number;
  commonInterests: string[];
}

interface LookingForCompany {
  id: string;
  name: string;
  profileImage: string;
  activity: string;
  location: string;
  timeframe: string;
  description: string;
  groupSize: string;
  postedTime: string;
}

const CURRENT_FRIENDS: Friend[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    profileImage: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    mutualFriends: 12,
    lastActivity: 'Active 2 hours ago',
    status: 'online',
  },
  {
    id: '2',
    name: 'Marcus Wong',
    profileImage: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    mutualFriends: 8,
    lastActivity: 'Active yesterday',
    status: 'offline',
  },
  {
    id: '3',
    name: 'Emily Tan',
    profileImage: 'https://images.pexels.com/photos/1130626/pexels-photo-1130626.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    mutualFriends: 15,
    lastActivity: 'Active 30 minutes ago',
    status: 'online',
  },
  {
    id: '4',
    name: 'David Lim',
    profileImage: 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    mutualFriends: 6,
    lastActivity: 'Active 3 days ago',
    status: 'offline',
  },
];

const FRIEND_RECOMMENDATIONS: FriendRecommendation[] = [
  {
    id: '5',
    name: 'Giselle Park',
    profileImage: 'https://images.pexels.com/photos/1858175/pexels-photo-1858175.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    reason: 'Giselle participated in Beach Volleyball at Sentosa Beach too.',
    mutualFriends: 3,
    commonInterests: ['Sports', 'Beach Activities'],
  },
  {
    id: '6',
    name: 'Andy Kumar',
    profileImage: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    reason: 'Andy has similar interests in outdoor activities.',
    mutualFriends: 5,
    commonInterests: ['Hiking', 'Photography', 'Adventure'],
  },
  {
    id: '7',
    name: 'Lisa Rodriguez',
    profileImage: 'https://images.pexels.com/photos/1036623/pexels-photo-1036623.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    reason: 'Lisa attended Rooftop Party at Chinatown Heritage Centre.',
    mutualFriends: 7,
    commonInterests: ['Nightlife', 'Social Events'],
  },
  {
    id: '8',
    name: 'James Mitchell',
    profileImage: 'https://images.pexels.com/photos/1681010/pexels-photo-1681010.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    reason: 'James loves food experiences like you.',
    mutualFriends: 4,
    commonInterests: ['Fine Dining', 'Cooking', 'Food Tours'],
  },
  {
    id: '9',
    name: 'Rachel Kim',
    profileImage: 'https://images.pexels.com/photos/1065084/pexels-photo-1065084.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    reason: 'Rachel frequently joins creative workshops in your area.',
    mutualFriends: 2,
    commonInterests: ['Art', 'Pottery', 'Creative Writing'],
  },
];

const LOOKING_FOR_COMPANY: LookingForCompany[] = [
  {
    id: '10',
    name: 'Alex Thompson',
    profileImage: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    activity: 'Morning Jog',
    location: 'East Coast Park',
    timeframe: 'Tomorrow 7:00 AM',
    description: 'Looking for a running buddy for my morning routine. Moderate pace, about 5km.',
    groupSize: '1-2 people',
    postedTime: '2 hours ago',
  },
  {
    id: '11',
    name: 'Priya Sharma',
    profileImage: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    activity: 'Coffee & Study Session',
    location: 'Starbucks Orchard',
    timeframe: 'This Weekend',
    description: 'Need a study buddy for my certification exam prep. Quiet company welcome!',
    groupSize: '1-3 people',
    postedTime: '4 hours ago',
  },
  {
    id: '12',
    name: 'Kevin Ng',
    profileImage: 'https://images.pexels.com/photos/1212984/pexels-photo-1212984.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    activity: 'Board Game Night',
    location: 'My Place (Tanjong Pagar)',
    timeframe: 'Friday 7:00 PM',
    description: 'Weekly board game session! We play Catan, Ticket to Ride, and more. Snacks provided.',
    groupSize: '3-6 people',
    postedTime: '6 hours ago',
  },
  {
    id: '13',
    name: 'Michelle Lee',
    profileImage: 'https://images.pexels.com/photos/1542085/pexels-photo-1542085.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    activity: 'Photography Walk',
    location: 'Chinatown Heritage District',
    timeframe: 'Sunday 3:00 PM',
    description: 'Exploring street photography around heritage buildings. Beginners welcome!',
    groupSize: '2-4 people',
    postedTime: '1 day ago',
  },
  {
    id: '14',
    name: 'Ryan Patel',
    profileImage: 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
    activity: 'Badminton Match',
    location: 'ActiveSG Toa Payoh',
    timeframe: 'Wednesday 8:00 PM',
    description: 'Regular badminton session, intermediate level. Court already booked!',
    groupSize: '1-3 people',
    postedTime: '1 day ago',
  },
];

export default function FriendsScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [addedFriends, setAddedFriends] = useState<Set<string>>(new Set());
  const [joinedActivities, setJoinedActivities] = useState<Set<string>>(new Set());

  const handleAddFriend = (friendId: string) => {
    setAddedFriends(prev => new Set([...prev, friendId]));
    // In a real app, this would make an API call to send friend request
    console.log(`Friend request sent to ${friendId}`);
  };

  const handleMessageFriend = (friendId: string) => {
    // In a real app, this would open chat with the friend
    console.log(`Opening chat with ${friendId}`);
  };

  const handleJoinActivity = (activityId: string) => {
    setJoinedActivities(prev => new Set([...prev, activityId]));
    // In a real app, this would make an API call to join the activity
    console.log(`Joined activity ${activityId}`);
  };

  const handleMessageForActivity = (personId: string) => {
    // In a real app, this would open chat with the person about the activity
    console.log(`Messaging ${personId} about activity`);
  };

  const renderFriendCard = (friend: Friend) => (
    <View key={friend.id} style={styles.friendCard}>
      <View style={styles.friendInfo}>
        <View style={styles.profileImageContainer}>
          <Image source={{ uri: friend.profileImage }} style={styles.profileImage} />
          <View style={[
            styles.statusIndicator,
            friend.status === 'online' ? styles.statusOnline : styles.statusOffline
          ]} />
        </View>
        
        <View style={styles.friendDetails}>
          <Text style={styles.friendName}>{friend.name}</Text>
          <Text style={styles.mutualFriends}>{friend.mutualFriends} mutual friends</Text>
          <Text style={styles.lastActivity}>{friend.lastActivity}</Text>
        </View>
      </View>
      
      <TouchableOpacity
        style={styles.messageButton}
        onPress={() => handleMessageFriend(friend.id)}
      >
        <MessageCircle size={20} color="#A8C2EE" />
      </TouchableOpacity>
    </View>
  );

  const renderRecommendationCard = (recommendation: FriendRecommendation) => {
    const isAdded = addedFriends.has(recommendation.id);
    
    return (
      <View key={recommendation.id} style={styles.recommendationCard}>
        <View style={styles.recommendationInfo}>
          <Image source={{ uri: recommendation.profileImage }} style={styles.profileImage} />
          
          <View style={styles.recommendationDetails}>
            <Text style={styles.recommendationName}>{recommendation.name}</Text>
            <Text style={styles.recommendationReason}>{recommendation.reason}</Text>
            <Text style={styles.mutualFriends}>{recommendation.mutualFriends} mutual friends</Text>
            
            <View style={styles.interestsContainer}>
              {recommendation.commonInterests.slice(0, 2).map((interest, index) => (
                <View key={index} style={styles.interestTag}>
                  <Text style={styles.interestText}>{interest}</Text>
                </View>
              ))}
              {recommendation.commonInterests.length > 2 && (
                <Text style={styles.moreInterests}>
                  +{recommendation.commonInterests.length - 2} more
                </Text>
              )}
            </View>
          </View>
        </View>
        
        <TouchableOpacity
          style={[
            styles.addButton,
            isAdded && styles.addButtonAdded
          ]}
          onPress={() => handleAddFriend(recommendation.id)}
          disabled={isAdded}
        >
          {isAdded ? (
            <Check size={20} color="white" />
          ) : (
            <UserPlus size={20} color="#A8C2EE" />
          )}
        </TouchableOpacity>
      </View>
    );
  };

  const renderLookingForCompanyCard = (person: LookingForCompany) => {
    const hasJoined = joinedActivities.has(person.id);
    
    return (
      <View key={person.id} style={styles.companyCard}>
        <View style={styles.companyHeader}>
          <Image source={{ uri: person.profileImage }} style={styles.profileImage} />
          
          <View style={styles.companyInfo}>
            <Text style={styles.companyName}>{person.name}</Text>
            <Text style={styles.companyActivity}>{person.activity}</Text>
            <Text style={styles.postedTime}>{person.postedTime}</Text>
          </View>
        </View>
        
        <Text style={styles.companyDescription}>{person.description}</Text>
        
        <View style={styles.companyDetails}>
          <View style={styles.companyDetailRow}>
            <MapPin size={16} color="#666" />
            <Text style={styles.companyDetailText}>{person.location}</Text>
          </View>
          
          <View style={styles.companyDetailRow}>
            <Clock size={16} color="#666" />
            <Text style={styles.companyDetailText}>{person.timeframe}</Text>
          </View>
          
          <View style={styles.companyDetailRow}>
            <Users size={16} color="#666" />
            <Text style={styles.companyDetailText}>{person.groupSize}</Text>
          </View>
        </View>
        
        <View style={styles.companyActions}>
          <TouchableOpacity
            style={styles.messageActionButton}
            onPress={() => handleMessageForActivity(person.id)}
          >
            <MessageCircle size={18} color="#A8C2EE" />
            <Text style={styles.messageActionText}>Message</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.joinButton,
              hasJoined && styles.joinButtonJoined
            ]}
            onPress={() => handleJoinActivity(person.id)}
            disabled={hasJoined}
          >
            {hasJoined ? (
              <>
                <Check size={18} color="white" />
                <Text style={styles.joinButtonTextJoined}>Joined</Text>
              </>
            ) : (
              <>
                <Calendar size={18} color="white" />
                <Text style={styles.joinButtonText}>Join</Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 10 }]}>
        <TouchableOpacity onPress={() => router.back()} style={styles.headerButton}>
          <ArrowLeft size={24} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Friends</Text>
        <TouchableOpacity style={styles.headerButton}>
          <Search size={24} color="#333" />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: insets.bottom + 20 }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Stats */}
        <View style={styles.statsContainer}>
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{CURRENT_FRIENDS.length}</Text>
            <Text style={styles.statLabel}>Friends</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>
              {CURRENT_FRIENDS.filter(f => f.status === 'online').length}
            </Text>
            <Text style={styles.statLabel}>Online</Text>
          </View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}>
            <Text style={styles.statValue}>{FRIEND_RECOMMENDATIONS.length}</Text>
            <Text style={styles.statLabel}>Suggestions</Text>
          </View>
        </View>

        {/* Current Friends */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Your Friends</Text>
            <TouchableOpacity>
              <Users size={20} color="#A8C2EE" />
            </TouchableOpacity>
          </View>
          
          {CURRENT_FRIENDS.map(renderFriendCard)}
        </View>

        {/* Friend Recommendations */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>People You May Know</Text>
            <TouchableOpacity>
              <Filter size={20} color="#A8C2EE" />
            </TouchableOpacity>
          </View>
          
          {FRIEND_RECOMMENDATIONS.map(renderRecommendationCard)}
        </View>

        {/* Looking for Company */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Looking for Company</Text>
            <TouchableOpacity>
              <Calendar size={20} color="#A8C2EE" />
            </TouchableOpacity>
          </View>
          <Text style={styles.sectionSubtitle}>
            People seeking activity partners in your area
          </Text>
          
          {LOOKING_FOR_COMPANY.map(renderLookingForCompanyCard)}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 10,
    backgroundColor: 'white',
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F8FF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    flex: 1,
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
    textAlign: 'center',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
  },
  statsContainer: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 20,
    marginBottom: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
  },
  statValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
  },
  statLabel: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  statDivider: {
    width: 1,
    height: '80%',
    backgroundColor: '#E0E0E0',
    alignSelf: 'center',
  },
  section: {
    marginBottom: 32,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#333',
  },
  sectionSubtitle: {
    fontSize: 14,
    color: '#666',
    marginBottom: 16,
    marginTop: -8,
  },
  friendCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  friendInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  profileImageContainer: {
    position: 'relative',
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  statusIndicator: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    borderWidth: 2,
    borderColor: 'white',
  },
  statusOnline: {
    backgroundColor: '#4CAF50',
  },
  statusOffline: {
    backgroundColor: '#999',
  },
  friendDetails: {
    marginLeft: 12,
    flex: 1,
  },
  friendName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  mutualFriends: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  lastActivity: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  messageButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F8FF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#D1DFFA',
  },
  recommendationCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  recommendationInfo: {
    flexDirection: 'row',
    flex: 1,
  },
  recommendationDetails: {
    marginLeft: 12,
    flex: 1,
  },
  recommendationName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 4,
  },
  recommendationReason: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
    marginBottom: 6,
  },
  interestsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    marginTop: 8,
  },
  interestTag: {
    backgroundColor: '#F5F8FF',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginRight: 6,
    marginBottom: 4,
  },
  interestText: {
    fontSize: 12,
    color: '#A8C2EE',
    fontWeight: '500',
  },
  moreInterests: {
    fontSize: 12,
    color: '#999',
    fontStyle: 'italic',
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#F5F8FF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#A8C2EE',
    marginTop: 4,
  },
  addButtonAdded: {
    backgroundColor: '#A8C2EE',
    borderColor: '#A8C2EE',
  },
  companyCard: {
    backgroundColor: 'white',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  companyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  companyInfo: {
    marginLeft: 12,
    flex: 1,
  },
  companyName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  companyActivity: {
    fontSize: 15,
    color: '#A8C2EE',
    fontWeight: '500',
    marginTop: 2,
  },
  postedTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  companyDescription: {
    fontSize: 14,
    color: '#555',
    lineHeight: 20,
    marginBottom: 12,
  },
  companyDetails: {
    marginBottom: 16,
  },
  companyDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  companyDetailText: {
    fontSize: 14,
    color: '#666',
    marginLeft: 8,
  },
  companyActions: {
    flexDirection: 'row',
    gap: 12,
  },
  messageActionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#A8C2EE',
    backgroundColor: 'white',
  },
  messageActionText: {
    fontSize: 14,
    color: '#A8C2EE',
    fontWeight: '500',
    marginLeft: 6,
  },
  joinButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: 8,
    backgroundColor: '#A8C2EE',
  },
  joinButtonJoined: {
    backgroundColor: '#4CAF50',
  },
  joinButtonText: {
    fontSize: 14,
    color: 'white',
    fontWeight: '600',
    marginLeft: 6,
  },
  joinButtonTextJoined: {
    fontSize: 14,
    color: 'white',
    fontWeight: '600',
    marginLeft: 6,
  },
});