import React from 'react';
import { View, Text, StyleSheet, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type FollowingItem = {
  id: string;
  name: string;
  activity: string;
  time: string;
};

const DATA: FollowingItem[] = [
  {
    id: '1',
    name: 'Sarah Johnson',
    activity: 'joined Beach Volleyball Meetup',
    time: '2 hours ago',
  },
  {
    id: '2',
    name: 'Mike Chen',
    activity: 'is attending Jazz Night',
    time: '5 hours ago',
  },
  {
    id: '3',
    name: 'Emma Wilson',
    activity: 'created Hiking Trip event',
    time: 'Yesterday',
  },
  {
    id: '4',
    name: 'James Lee',
    activity: 'joined Book Club Discussion',
    time: 'Yesterday',
  },
  {
    id: '5',
    name: 'Olivia Garcia',
    activity: 'is attending Art Gallery Opening',
    time: '2 days ago',
  },
];

export default function FollowingScreen() {
  const insets = useSafeAreaInsets();

  const renderItem = ({ item }: { item: FollowingItem }) => (
    <View style={styles.activityItem}>
      <View style={styles.activityContent}>
        <Text style={styles.nameText}>{item.name}</Text>
        <Text style={styles.activityText}>{item.activity}</Text>
        <Text style={styles.timeText}>{item.time}</Text>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        contentContainerStyle={[
          styles.listContent,
          { paddingBottom: insets.bottom + 20 }
        ]}
        showsVerticalScrollIndicator={false}
        ListHeaderComponent={
          <Text style={styles.header}>Activity Feed</Text>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  header: {
    fontSize: 22,
    fontWeight: '600',
    color: '#333',
    marginBottom: 20,
    paddingHorizontal: 16,
  },
  listContent: {
    paddingTop: 20,
    paddingHorizontal: 16,
  },
  activityItem: {
    backgroundColor: 'white',
    borderRadius: 12,
    marginBottom: 12,
    padding: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  activityContent: {
    flex: 1,
  },
  nameText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  activityText: {
    fontSize: 14,
    color: '#555',
    marginTop: 4,
  },
  timeText: {
    fontSize: 12,
    color: '#888',
    marginTop: 8,
  },
});