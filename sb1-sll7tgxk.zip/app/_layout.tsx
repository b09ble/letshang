import { useEffect } from 'react';
import { Tabs } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import HeaderBar from '@/components/HeaderBar';
import TabBar from '@/components/TabBar';
import { Footprints, Heart, User } from 'lucide-react-native';

export default function RootLayout() {
  useFrameworkReady();

  return (
    <>
      <StatusBar style="light" />
      <Tabs
        screenOptions={{
          headerShown: true,
          header: () => <HeaderBar />,
          tabBarStyle: {
            height: 60,
            backgroundColor: '#A8C2EE',
            borderTopWidth: 0,
          },
        }}
        tabBar={props => <TabBar {...props} />}
      >
        <Tabs.Screen
          name="home"
          options={{
            title: 'Home',
            tabBarLabel: 'Home',
            tabBarIcon: ({ color }) => <Footprints color={color} size={24} />,
          }}
        />
        <Tabs.Screen
          name="following"
          options={{
            title: 'Following',
            tabBarLabel: 'Following',
            tabBarIcon: ({ color }) => <Footprints color={color} size={24} />,
          }}
        />
        <Tabs.Screen
          name="favorites"
          options={{
            title: 'Favourites',
            tabBarLabel: 'Favourites',
            tabBarIcon: ({ color }) => <Heart color={color} size={24} />,
          }}
        />
        <Tabs.Screen
          name="me"
          options={{
            title: 'Me',
            tabBarLabel: 'Me',
            tabBarIcon: ({ color }) => <User color={color} size={24} />,
          }}
        />
        <Tabs.Screen
          name="+not-found"
          options={{
            href: null,
          }}
        />
      </Tabs>
    </>
  );
}