import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { ChevronLeft, ChevronRight } from 'lucide-react-native';
import Animated, { 
  FadeIn, 
  FadeOut, 
  SlideInRight, 
  SlideOutLeft 
} from 'react-native-reanimated';

interface Question {
  id: number;
  text: string;
  options: string[];
}

const questions: Question[] = [
  {
    id: 1,
    text: 'How much are you willing to spend?',
    options: ['$0 (Free)', '$1-$25', '$26-$50', '$51-$100', '$100+']
  },
  {
    id: 2,
    text: 'How far are you willing to travel right now?',
    options: ['< 1km', '1-5km', '5-10km', '10-20km', '20km+']
  },
  {
    id: 3,
    text: 'Who are you going with?',
    options: ['Solo', 'With a friend', '2-3 friends', '4-6 friends', 'Large group (7+)']
  },
  {
    id: 4,
    text: 'What kind of environment do you prefer?',
    options: ['Indoors', 'Outdoors', 'Mix of both']
  },
  {
    id: 5,
    text: 'Are you looking to explore something new?',
    options: ['Familiar places', 'New experiences', 'Mix of both']
  },
  {
    id: 6,
    text: 'What vibe are you craving right now?',
    options: ['Energetic & Social', 'Calm & Relaxing', 'Creative & Artistic', 'Active & Sporty', 'Cozy & Intimate']
  },
  {
    id: 7,
    text: 'What would you like to do?',
    options: ['Eat & Drink', 'Walk & Explore', 'Shop', 'Create & Learn', 'Play & Exercise', 'Relax & Unwind']
  }
];

const AnimatedTouchableOpacity = Animated.createAnimatedComponent(TouchableOpacity);

export default function Questionnaire() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const router = useRouter();
  
  const handleAnswer = (answer: string) => {
    setAnswers(prev => ({ ...prev, [currentQuestion]: answer }));
    
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      router.push('/recommendations');
    }
  };

  const handleBack = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    } else if (router.canGoBack()) {
      router.back();
    } else {
      router.replace('/');
    }
  };

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton}>
          <ChevronLeft color="#333" size={24} />
        </TouchableOpacity>
        <Text style={styles.questionCount}>
          Question {currentQuestion + 1} of {questions.length}
        </Text>
      </View>

      <View style={styles.progressBarContainer}>
        <View style={[styles.progressBar, { width: `${progress}%` }]} />
      </View>

      <ScrollView 
        style={styles.content}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
      >
        <Animated.View
          entering={SlideInRight}
          exiting={SlideOutLeft}
          key={question.id}
          style={styles.questionContainer}
        >
          <Text style={styles.questionText}>{question.text}</Text>
          
          <View style={styles.optionsContainer}>
            {question.options.map((option, index) => (
              <AnimatedTouchableOpacity
                key={option}
                style={[
                  styles.optionButton,
                  answers[currentQuestion] === option && styles.selectedOption
                ]}
                onPress={() => handleAnswer(option)}
                entering={FadeIn.delay(index * 100)}
                exiting={FadeOut}
              >
                <Text style={[
                  styles.optionText,
                  answers[currentQuestion] === option && styles.selectedOptionText
                ]}>
                  {option}
                </Text>
                {answers[currentQuestion] === option && (
                  <ChevronRight color="#FFF" size={20} />
                )}
              </AnimatedTouchableOpacity>
            ))}
          </View>
        </Animated.View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F8FF',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    paddingTop: Platform.OS === 'ios' ? 60 : 16,
    backgroundColor: '#FFF',
  },
  backButton: {
    padding: 8,
  },
  questionCount: {
    flex: 1,
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginRight: 40,
  },
  progressBarContainer: {
    height: 4,
    backgroundColor: '#E0E0E0',
    width: '100%',
  },
  progressBar: {
    height: '100%',
    backgroundColor: '#A8C2EE',
    borderRadius: 2,
    transition: 'width 0.3s ease-in-out',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    padding: 24,
  },
  questionContainer: {
    flex: 1,
  },
  questionText: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginBottom: 32,
  },
  optionsContainer: {
    gap: 12,
  },
  optionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
    backgroundColor: '#FFF',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#E0E0E0',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 3,
    elevation: 2,
  },
  selectedOption: {
    backgroundColor: '#A8C2EE',
    borderColor: '#A8C2EE',
  },
  optionText: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  selectedOptionText: {
    color: '#FFF',
    fontWeight: '600',
  },
});